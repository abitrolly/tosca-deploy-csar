#!/bin/bash

echo "chkconfig httpd"
chkconfig httpd on