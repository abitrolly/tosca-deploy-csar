#!/bin/bash

service mysqld restart