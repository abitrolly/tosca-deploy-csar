#!/bin/bash

service mysqld stop